/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.ArrayList;

/**
 *
 * @author Vidya
 */
public class Graph {
    
    int ver;
    ArrayList<ArrayList<Integer>> vertexArray = new ArrayList<>();
    
    
    public Graph(int ver){
        this.ver = ver;
        this.vertexArray = new ArrayList<>(ver);
        for(int i = 0; i <ver; i++){
           
           this.vertexArray.add( new ArrayList<Integer>());
           
        }
        
    }
    
    public void addEdge(int src, int dest){
       
       ArrayList<Integer> connnectedNodeList = this.vertexArray.get(src);
       connnectedNodeList.add(dest);
    }
    
}

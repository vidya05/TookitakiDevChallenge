/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;

/**
 *
 * @author Vidya
 */
public class Stack {
    ArrayList<Integer> arr = new ArrayList<>();
    
    public void push(int value){
        arr.add(value);
    }
    
    public int pop(){
        int ret = -1;
        if(!this.arr.isEmpty()){
            ret =  arr.get(arr.size()-1);
            arr.remove(arr.size()-1);
        }
        return ret;
    }
    
    public boolean isEmpty(){
        return arr.isEmpty();
    }
}
